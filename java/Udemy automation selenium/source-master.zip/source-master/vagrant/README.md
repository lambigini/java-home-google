Hub logs:

  vagrant ssh hub
  sudo cat /var/log/upstart/selenium-hub.log

Node logs (for Ubuntu Firefox):

  vagrant ssh node-ubuntu-firefox
  sudo cat /var/log/upstart/selenium-node.log

You must set-up the Windows node using the instructions in chapter 10 of the book. 
