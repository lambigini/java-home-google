package swb.misc.geolocation;

public enum GeolocationStatus {
    OK,
    PERMISSION_DENIED
}
