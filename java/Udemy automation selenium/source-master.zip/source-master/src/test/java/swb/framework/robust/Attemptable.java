package swb.framework.robust;

public interface Attemptable {
    void attempt() throws Exception;
}
