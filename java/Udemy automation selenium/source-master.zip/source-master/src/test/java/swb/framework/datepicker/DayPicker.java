package swb.framework.datepicker;

public interface DayPicker {
    void pick(int day);
}
