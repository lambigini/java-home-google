package swb.ch18datepicker.datepicker.v1;

public interface DayPicker {
    void pick(int day);
}
