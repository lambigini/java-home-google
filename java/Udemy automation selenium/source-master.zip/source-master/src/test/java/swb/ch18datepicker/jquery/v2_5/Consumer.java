package swb.ch18datepicker.jquery.v2_5;

public interface Consumer<T> {
    void accept(T t);
}